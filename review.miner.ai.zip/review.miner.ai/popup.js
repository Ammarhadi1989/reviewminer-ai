const FREE_LIMIT = 3;
const CHECKOUT_URL = "https://reviewminer-ai.lemonsqueezy.com/checkout/buy/f3faed82-b0e1-4ca1-be10-fcd862bc40bd";

// Valideringsfunktion för Pro-licens (Alla nycklar som börjar på "RM-PRO-" räknas som giltiga Pro-licenser)
function isProLicense(key) {
    if (!key) return false;
    return key.trim().toUpperCase().startsWith("RM-PRO-");
}

document.addEventListener('DOMContentLoaded', () => {
    updateUIState();

    // Automatisk sparande när licensnyckeln ändras
    document.getElementById('license-key').addEventListener('input', (e) => {
        const key = e.target.value.trim();
        chrome.storage.local.set({ license_key: key }, () => {
            updateUIState();
        });
    });

    // Automatisk sparande när OpenAI API-nyckeln ändras
    document.getElementById('api-key').addEventListener('input', (e) => {
        chrome.storage.local.set({ openai_api_key: e.target.value.trim() });
    });

    // Klick på den gröna upgrade-knappen när gratisanalyser är slut
    const upgradeBtn = document.getElementById('upgrade-btn');
    if (upgradeBtn) {
        upgradeBtn.addEventListener('click', () => {
            chrome.tabs.create({ url: CHECKOUT_URL });
        });
    }

    // Klick på den blå textlänken under licensfältet
    const buyProLink = document.getElementById('buy-pro-link');
    if (buyProLink) {
        buyProLink.addEventListener('click', (e) => {
            e.preventDefault();
            chrome.tabs.create({ url: CHECKOUT_URL });
        });
    }
});

function updateUIState() {
    chrome.storage.local.get(['openai_api_key', 'license_key', 'used_count'], (data) => {
        const apiKey = data.openai_api_key || "";
        const licenseKey = data.license_key || "";
        const usedCount = data.used_count || 0;

        if (apiKey) document.getElementById('api-key').value = apiKey;
        if (licenseKey) document.getElementById('license-key').value = licenseKey;

        const isPro = isProLicense(licenseKey);
        const badge = document.getElementById('plan-badge');
        const mineBtn = document.getElementById('mine-btn');
        const upgradeBtn = document.getElementById('upgrade-btn');
        const statusDiv = document.getElementById('status');

        if (isPro) {
            badge.innerText = "⭐ PRO Aktiv";
            badge.className = "badge pro";
            mineBtn.disabled = false;
            upgradeBtn.style.display = "none";
            statusDiv.innerText = "";
        } else {
            const remaining = Math.max(0, FREE_LIMIT - usedCount);
            badge.innerText = `🆓 ${remaining} av ${FREE_LIMIT} gratis kvar`;
            badge.className = "badge free";

            if (remaining <= 0) {
                mineBtn.disabled = true;
                upgradeBtn.style.display = "block";
                statusDiv.innerText = "Du har förbrukat dina gratisanalyser.";
            } else {
                mineBtn.disabled = false;
                upgradeBtn.style.display = "none";
                statusDiv.innerText = "";
            }
        }
    });
}

document.getElementById('mine-btn').addEventListener('click', async () => {
    const statusDiv = document.getElementById('status');
    const resultsDiv = document.getElementById('results');
    const apiKey = document.getElementById('api-key').value.trim();
    const licenseKey = document.getElementById('license-key').value.trim();

    if (!apiKey) {
        statusDiv.innerText = "Ange din OpenAI API-nyckel.";
        return;
    }

    statusDiv.innerText = "Läser av recensioner på sidan...";
    resultsDiv.style.display = 'none';

    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    chrome.tabs.sendMessage(tab.id, { action: "extract_reviews" }, async (response) => {
        if (chrome.runtime.lastError || !response || !response.reviews || response.reviews.length === 0) {
            statusDiv.innerText = "Hittade inga recensioner. Gå till en produktsida på Trustpilot/Amazon.";
            return;
        }

        statusDiv.innerText = `Analyserar ${response.reviews.length} recensioner med AI...`;
        const sampleReviews = response.reviews.slice(0, 20).join("\n---\n");

        try {
            const aiResponse = await fetch("https://api.openai.com/v1/chat/completions", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${apiKey}`
                },
                body: JSON.stringify({
                    model: "gpt-4o-mini",
                    messages: [
                        {
                            role: "system",
                            content: "Du är en expert på produktutveckling. Analysera recensionerna och svara EXAKT i följande JSON-format utan markdown-block: {\"pain_points\": \"...\", \"missing_features\": \"...\", \"opportunity\": \"...\"}. Svara på svenska."
                        },
                        {
                            role: "user",
                            content: `Analysera dessa recensioner:\n${sampleReviews}`
                        }
                    ],
                    temperature: 0.3
                })
            });

            const data = await aiResponse.json();

            if (data.error) {
                statusDiv.innerText = "Fel från OpenAI: " + data.error.message;
                return;
            }

            const content = JSON.parse(data.choices[0].message.content);

            document.getElementById('pain-points').innerText = content.pain_points;
            document.getElementById('missing-features').innerText = content.missing_features;
            document.getElementById('opportunity').innerText = content.opportunity;

            statusDiv.innerText = "Analys klar!";
            resultsDiv.style.display = 'block';

            // Öka gratisräknaren om användaren inte har Pro
            if (!isProLicense(licenseKey)) {
                chrome.storage.local.get(['used_count'], (res) => {
                    const current = res.used_count || 0;
                    chrome.storage.local.set({ used_count: current + 1 }, () => {
                        updateUIState();
                    });
                });
            }

        } catch (err) {
            statusDiv.innerText = "Ett fel uppstod vid AI-analysen: " + err.message;
        }
    });
});