chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "extract_reviews") {
        let reviews = [];

        // 1. Sök i alla recensionskort på Trustpilot (artiklar)
        const cards = document.querySelectorAll('article, [data-testid="review-card"]');
        cards.forEach(card => {
            const paragraphs = card.querySelectorAll('p');
            paragraphs.forEach(p => {
                let text = p.innerText.trim();
                if (text.length > 20 && !reviews.includes(text)) {
                    reviews.push(text);
                }
            });
        });

        // 2. Om vi inte hittar kort (t.ex. på Amazon), sök med generella selektorer
        if (reviews.length === 0) {
            let genericSelectors = [
                '[data-hook="review-collapsed"]',
                '.review-text-content span',
                '[class*="review-text"]',
                '[class*="typography_body"]'
            ];

            let elements = document.querySelectorAll(genericSelectors.join(','));
            elements.forEach(el => {
                let text = el.innerText.trim();
                if (text.length > 20 && !reviews.includes(text)) {
                    reviews.push(text);
                }
            });
        }

        sendResponse({ reviews: reviews });
    }
    return true;
});